VibBox wireless test (ESP-NOW), v0.1
=====================================

Two sketches, one for each ESP32:
  vibbox_station_test  -> the ESP32 that stays at the laptop (no wires, just USB)
  vibbox_probe_test    -> the ESP32 with the MPU on jumper wires

MPU wiring on the probe ESP32 (the same pins as the VibBox v1.4 box):
  MPU VCC -> 3V3
  MPU GND -> GND
  MPU SCL -> D18
  MPU SDA -> D23
  MPU AD0 -> D19
  MPU NCS -> D5
  (leave EDA, ECL, INT, FSYNC unconnected)

Steps
1. Arduino IDE: Tools > Board > ESP32 Dev Module.
2. Plug in the station ESP32, open vibbox_station_test, Upload.
   Open the Serial Monitor at 115200. It says "Calling the probe...".
3. Plug in the probe ESP32, open vibbox_probe_test, Upload.
   You can then power the probe from a phone charger or power bank.
4. Watch the station's Serial Monitor. About once a second you get one block:
      Block 7: 103/103 packets OK | signal -42 dBm | 4002 readings/s
         RMS here  x 0.0031  y 0.0029  z 0.0040 g
         RMS probe x 0.0031  y 0.0029  z 0.0040 g
         data check: MATCH, the data arrived exactly
         biggest peak: z axis, 50.0 Hz, 0.0012 g
         level |#                        | 0.006 g
5. Tests to try:
   - tap the sensor or the table: the level bar jumps
   - hold it on a running fan or a phone on vibrate: the biggest peak shows its speed
   - walk away with the probe on a power bank, through a wall: watch the signal
     and the "lost" numbers

What good looks like
   data check: MATCH on every block
   lost before resend: under about 5 %, and 0 blocks failed
   signal: -40 to -70 dBm is good, about -80 is weak, below -90 it drops out

If something is wrong
   "Still waiting for the probe": the probe is off, or not running the probe sketch.
   "MPU chip ID 0x00 or 0xFF": a wire is loose or on the wrong pin (probe Serial Monitor).
   Compile error about esp_now: tell me the exact error and your ESP32 board version
   (Tools > Board > Boards Manager > esp32).

Both use Wi-Fi channel 1. The real station later runs the "VibSensor" Wi-Fi on the
same channel, so this link keeps working next to the iPad page.
