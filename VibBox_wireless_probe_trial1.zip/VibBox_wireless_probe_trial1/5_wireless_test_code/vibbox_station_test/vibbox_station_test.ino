// VibBox wireless test: STATION (receiver)   v0.1
// Sends a small "I am here" beacon every half second, so the probe finds it by itself
// (no MAC addresses to type). Receives each block of 4096 readings, asks the probe for
// any missing packets, then checks the data really arrived the same:
//   - its own RMS and check number must match the probe's
//   - it finds the biggest vibration peak (tap the sensor, or put it on a fan)
//
// Arduino IDE: Tools > Board > ESP32 Dev Module. Serial Monitor at 115200.
// Nothing to wire: just USB.

#include <WiFi.h>
#include <esp_wifi.h>
#include <esp_now.h>
#include <esp_idf_version.h>
#include <math.h>

const int PIN_LED = 2;
const int CHANNEL = 1;            // must be the same on the probe
const int NMAX = 4096;
const int PER_PKT = 40;
const int MAXPKT = 128;

#define MAGIC 0xB5
enum : uint8_t { T_BEACON = 1, T_INFO = 2, T_DATA = 3, T_REPORT = 4 };
struct __attribute__((packed)) Beacon { uint8_t magic, type, channel; };
struct __attribute__((packed)) Info {
  uint8_t magic, type;
  uint16_t block, n, packets, perPkt, lsbPerG;
  float fs, rms[3];
  uint32_t sum;
};
struct __attribute__((packed)) DataPkt {
  uint8_t magic, type;
  uint16_t block, index, count;
  int16_t s[PER_PKT][3];
};
struct __attribute__((packed)) Report {
  uint8_t magic, type;
  uint16_t block, missing;
  uint8_t bits[16];
};

const uint8_t BROADCAST[6] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
int16_t rx[NMAX][3];
float re[NMAX], im[NMAX];

// filled by the receive callback
volatile bool blockActive = false;
volatile uint16_t curBlock = 0, nPackets = 0, gotCount = 0;
volatile uint32_t lastPktMs = 0, lastAnyMs = 0;
volatile int8_t lastRssi = 0;
volatile bool probeNew = false;
uint8_t gotBits[16];
Info info;
uint8_t probeMac[6], newMac[6];
bool haveProbe = false;

// used by loop()
uint16_t countAtLastReport = 0xFFFF;
int lostFirst = -1, reportsSent = 0;
uint32_t blocksOk = 0, blocksFailed = 0, pktsExpected = 0, pktsLostFirst = 0, badChecks = 0;

void handlePacket(const uint8_t* mac, const uint8_t* data, int len, int rssi) {
  if (len < 2 || data[0] != MAGIC) return;
  lastAnyMs = millis();
  if (rssi) lastRssi = rssi;
  if (!haveProbe || memcmp(probeMac, mac, 6) != 0) { memcpy(newMac, mac, 6); probeNew = true; }
  if (data[1] == T_INFO && len >= (int)sizeof(Info)) {
    const Info* in = (const Info*)data;
    if (blockActive && in->block == curBlock) return;          // the same block again
    memcpy(&info, data, sizeof(Info));
    if (info.n > NMAX) info.n = NMAX;
    curBlock = info.block;
    nPackets = info.packets > MAXPKT ? MAXPKT : info.packets;
    memset(gotBits, 0, sizeof(gotBits));
    gotCount = 0;
    lastPktMs = millis();
    blockActive = true;
  } else if (data[1] == T_DATA && len >= 8) {
    const DataPkt* d = (const DataPkt*)data;
    if (!blockActive || d->block != curBlock || d->index >= nPackets) return;
    if (gotBits[d->index >> 3] & (1 << (d->index & 7))) { lastPktMs = millis(); return; }
    int first = d->index * PER_PKT;
    int cnt = d->count;
    if (cnt > PER_PKT || len < 8 + cnt * 6 || first + cnt > NMAX) return;
    memcpy(rx[first], d->s, cnt * 6);
    gotBits[d->index >> 3] |= (1 << (d->index & 7));
    gotCount = gotCount + 1;
    lastPktMs = millis();
  }
}

#if ESP_IDF_VERSION_MAJOR >= 5
void onRecv(const esp_now_recv_info_t* inf, const uint8_t* data, int len) {
  handlePacket(inf->src_addr, data, len, inf->rx_ctrl ? inf->rx_ctrl->rssi : 0);
}
#else
void onRecv(const uint8_t* mac, const uint8_t* data, int len) { handlePacket(mac, data, len, 0); }
#endif

void addPeer(const uint8_t* mac) {
  esp_now_peer_info_t peer;
  memset(&peer, 0, sizeof(peer));
  memcpy(peer.peer_addr, mac, 6);
  peer.channel = 0;
  peer.encrypt = false;
  esp_now_add_peer(&peer);
}

void sendReport() {
  Report r;
  memset(&r, 0, sizeof(r));
  r.magic = MAGIC;
  r.type = T_REPORT;
  r.block = curBlock;
  uint16_t miss = 0;
  for (int p = 0; p < nPackets; p++)
    if (!(gotBits[p >> 3] & (1 << (p & 7)))) { r.bits[p >> 3] |= (1 << (p & 7)); miss++; }
  r.missing = miss;
  if (lostFirst < 0) lostFirst = miss;
  esp_now_send(probeMac, (const uint8_t*)&r, sizeof(r));
  reportsSent++;
}

void fft(float* xr, float* xi, int n) {
  for (int i = 1, j = 0; i < n; i++) {
    int bit = n >> 1;
    for (; j & bit; bit >>= 1) j ^= bit;
    j ^= bit;
    if (i < j) { float t = xr[i]; xr[i] = xr[j]; xr[j] = t; t = xi[i]; xi[i] = xi[j]; xi[j] = t; }
  }
  for (int len = 2; len <= n; len <<= 1) {
    float ang = -2.0f * (float)M_PI / len;
    float wr = cosf(ang), wi = sinf(ang);
    for (int i = 0; i < n; i += len) {
      float cr = 1, ci = 0;
      for (int k = 0; k < len / 2; k++) {
        int a = i + k, b = i + k + len / 2;
        float tr = xr[b] * cr - xi[b] * ci, ti = xr[b] * ci + xi[b] * cr;
        xr[b] = xr[a] - tr; xi[b] = xi[a] - ti;
        xr[a] += tr; xi[a] += ti;
        float nc = cr * wr - ci * wi;
        ci = cr * wi + ci * wr;
        cr = nc;
      }
    }
  }
}

// biggest peak above 5 Hz on one axis: returns frequency, amp = peak amplitude in g
float peakOf(int axis, int n, float fs, float lsb, float& amp) {
  double m = 0;
  for (int i = 0; i < n; i++) m += rx[i][axis];
  m /= n;
  float wsum = 0;
  for (int i = 0; i < n; i++) {
    float w = 0.5f - 0.5f * cosf(2.0f * (float)M_PI * i / (n - 1));
    re[i] = (float)(rx[i][axis] - m) / lsb * w;
    im[i] = 0;
    wsum += w;
  }
  fft(re, im, n);
  int kmin = (int)(5.0f * n / fs) + 1, best = kmin;
  float bestA = 0;
  for (int k = kmin; k < n / 2; k++) {
    float a = 2.0f * sqrtf(re[k] * re[k] + im[k] * im[k]) / wsum;
    if (a > bestA) { bestA = a; best = k; }
  }
  amp = bestA;
  return best * fs / n;
}

void bar(float g) {                    // 0 to 0.5 g in 25 steps
  int k = (int)(g / 0.02f + 0.5f);
  if (k > 25) k = 25;
  Serial.print("   level |");
  for (int i = 0; i < 25; i++) Serial.print(i < k ? '#' : ' ');
  Serial.printf("| %.3f g\n", g);
}

void processBlock() {
  int n = info.n;
  float lsb = info.lsbPerG ? info.lsbPerG : 4096;
  float rms[3];
  for (int a = 0; a < 3; a++) {
    double m = 0, q = 0;
    for (int i = 0; i < n; i++) m += rx[i][a];
    m /= n;
    for (int i = 0; i < n; i++) { double d = rx[i][a] - m; q += d * d; }
    rms[a] = (float)(sqrt(q / n) / lsb);
  }
  uint32_t sum = 0;
  for (int i = 0; i < n; i++) for (int a = 0; a < 3; a++) sum += (uint16_t)rx[i][a];
  bool match = (sum == info.sum);
  if (!match) badChecks++;
  float bestF = 0, bestA = 0;
  int bestAxis = 0;
  if ((n & (n - 1)) == 0) {
    for (int a = 0; a < 3; a++) {
      float amp;
      float f = peakOf(a, n, info.fs, lsb, amp);
      if (amp > bestA) { bestA = amp; bestF = f; bestAxis = a; }
    }
  }
  pktsExpected += nPackets;
  pktsLostFirst += (lostFirst > 0 ? lostFirst : 0);
  float lostPct = pktsExpected ? 100.0f * pktsLostFirst / pktsExpected : 0;

  Serial.printf("Block %u: %u/%u packets OK", curBlock, gotCount, nPackets);
  if (lostFirst > 0) Serial.printf(" (%d lost on the way, sent again)", lostFirst);
#if ESP_IDF_VERSION_MAJOR >= 5
  Serial.printf(" | signal %d dBm", lastRssi);
#endif
  Serial.printf(" | %.0f readings/s\n", info.fs);
  Serial.printf("   RMS here  x %.4f  y %.4f  z %.4f g\n", rms[0], rms[1], rms[2]);
  Serial.printf("   RMS probe x %.4f  y %.4f  z %.4f g\n", info.rms[0], info.rms[1], info.rms[2]);
  Serial.printf("   data check: %s\n", match ? "MATCH, the data arrived exactly" : "DIFFERENT (data damaged!)");
  if (bestA > 0) Serial.printf("   biggest peak: %c axis, %.1f Hz, %.4f g\n", "xyz"[bestAxis], bestF, bestA);
  bar(sqrtf(rms[0] * rms[0] + rms[1] * rms[1] + rms[2] * rms[2]));
  Serial.printf("   so far: %lu blocks ok, %lu failed, %.2f %% packets lost before resend, %lu bad checks\n\n",
                (unsigned long)blocksOk, (unsigned long)blocksFailed, lostPct, (unsigned long)badChecks);
}

void setup() {
  Serial.begin(115200);
  delay(300);
  pinMode(PIN_LED, OUTPUT);
  Serial.println("\nVibBox wireless test: STATION v0.1");
  WiFi.mode(WIFI_STA);
  WiFi.disconnect();
  esp_wifi_set_ps(WIFI_PS_NONE);
  esp_wifi_set_channel(CHANNEL, WIFI_SECOND_CHAN_NONE);
  Serial.print("This station: ");
  Serial.println(WiFi.macAddress());
  if (esp_now_init() != ESP_OK) { Serial.println("ESP-NOW did not start. Press EN to restart."); return; }
  esp_now_register_recv_cb(onRecv);
  addPeer(BROADCAST);
  Serial.println("Calling the probe...");
}

void loop() {
  static uint32_t tBeacon = 0, tHint = 0;
  if (millis() - tBeacon > 500) {
    tBeacon = millis();
    Beacon b = {MAGIC, T_BEACON, (uint8_t)CHANNEL};
    esp_now_send(BROADCAST, (const uint8_t*)&b, sizeof(b));
  }
  if (probeNew) {
    probeNew = false;
    if (haveProbe) esp_now_del_peer(probeMac);
    memcpy(probeMac, newMac, 6);
    addPeer(probeMac);
    haveProbe = true;
    Serial.printf("Probe found: %02X:%02X:%02X:%02X:%02X:%02X\n",
                  probeMac[0], probeMac[1], probeMac[2], probeMac[3], probeMac[4], probeMac[5]);
  }
  if (blockActive) {
    static uint16_t lastBlockSeen = 0;
    if (curBlock != lastBlockSeen) {   // a new block started
      lastBlockSeen = curBlock;
      countAtLastReport = 0xFFFF;
      lostFirst = -1;
      reportsSent = 0;
    }
    bool complete = (gotCount == nPackets);
    uint32_t quiet = millis() - lastPktMs;
    if (complete) {
      sendReport();                    // "missing 0": the probe can go on
      digitalWrite(PIN_LED, HIGH);
      blocksOk++;
      processBlock();
      blockActive = false;
      digitalWrite(PIN_LED, LOW);
    } else if (quiet > 150 && gotCount != countAtLastReport) {
      countAtLastReport = gotCount;
      sendReport();                    // ask for the missing packets
    } else if (quiet > 3000) {
      blocksFailed++;
      Serial.printf("Block %u FAILED: got %u of %u packets\n\n", curBlock, gotCount, nPackets);
      blockActive = false;
    }
  }
  if (millis() - lastAnyMs > 5000 && millis() - tHint > 5000) {
    tHint = millis();
    Serial.println(haveProbe ? "No data from the probe for 5 s (is it on? same channel?)"
                             : "Still waiting for the probe (upload vibbox_probe_test to the other ESP32)");
  }
  delay(1);
}
