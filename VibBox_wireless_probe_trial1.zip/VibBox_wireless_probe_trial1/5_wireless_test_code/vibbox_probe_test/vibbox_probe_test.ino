// VibBox wireless test: PROBE (sender)   v0.1
// Reads the MPU, records 4096 readings (about 1 second), and sends them to the
// station ESP32 over ESP-NOW. The station tells it which packets went missing,
// and the probe sends those again. Upload vibbox_station_test to the other ESP32.
//
// Arduino IDE: Tools > Board > ESP32 Dev Module. Serial Monitor at 115200.
//
// MPU wiring (the same pins as the VibBox v1.4 box), 6 jumper wires:
//   VCC -> 3V3   GND -> GND   SCL -> D18   SDA -> D23   AD0 -> D19   NCS -> D5
// Power: USB cable, or later the battery module (5 V to the 5V/VIN pin).

#include <SPI.h>
#include <WiFi.h>
#include <esp_wifi.h>
#include <esp_now.h>
#include <esp_idf_version.h>

const int PIN_SCK = 18, PIN_MISO = 19, PIN_MOSI = 23, PIN_CS = 5;
const int PIN_LED = 2;            // blue LED on most ESP32 boards (harmless if yours has none)
const int CHANNEL = 1;            // must be the same on the station
const int N = 4096;               // readings per block
const int PER_PKT = 40;           // readings per packet (40 x 3 axes x 2 bytes = 240 bytes)
const int NPKT = (N + PER_PKT - 1) / PER_PKT;   // 103 packets per block

SPISettings slowSPI(1000000, MSBFIRST, SPI_MODE3);   // settings: max 1 MHz
SPISettings fastSPI(4000000, MSBFIRST, SPI_MODE3);   // reading data: 4 MHz

// ---------------- packets (the station uses the same layout) ----------------
#define MAGIC 0xB5
enum : uint8_t { T_BEACON = 1, T_INFO = 2, T_DATA = 3, T_REPORT = 4 };
struct __attribute__((packed)) Beacon { uint8_t magic, type, channel; };
struct __attribute__((packed)) Info {
  uint8_t magic, type;
  uint16_t block, n, packets, perPkt, lsbPerG;
  float fs, rms[3];
  uint32_t sum;
};
struct __attribute__((packed)) DataPkt {
  uint8_t magic, type;
  uint16_t block, index, count;
  int16_t s[PER_PKT][3];
};
struct __attribute__((packed)) Report {
  uint8_t magic, type;
  uint16_t block, missing;
  uint8_t bits[16];               // bit i = 1: packet i is missing
};
static_assert(sizeof(DataPkt) <= 250, "ESP-NOW packets are 250 bytes at most");

int16_t buf[N][3];
float fsSensor = 4000;
int rangeG = 8;

volatile bool stationNew = false;
bool haveStation = false;
uint8_t stationMac[6];
uint8_t newMac[6];
volatile bool reportReady = false;
Report lastReport;
uint16_t blockId = 0;
uint32_t totalSent = 0, totalResent = 0, blocksOk = 0, blocksFailed = 0;

// ---------------- MPU helpers (from VibBox v1.4) ----------------
void writeReg(uint8_t reg, uint8_t val) {
  SPI.beginTransaction(slowSPI);
  digitalWrite(PIN_CS, LOW);
  SPI.transfer(reg & 0x7F);
  SPI.transfer(val);
  digitalWrite(PIN_CS, HIGH);
  SPI.endTransaction();
  delayMicroseconds(20);
}

uint8_t readReg(uint8_t reg) {
  SPI.beginTransaction(slowSPI);
  digitalWrite(PIN_CS, LOW);
  SPI.transfer(reg | 0x80);
  uint8_t v = SPI.transfer(0x00);
  digitalWrite(PIN_CS, HIGH);
  SPI.endTransaction();
  return v;
}

void readAccelBytes(uint8_t* b) {      // call inside a fastSPI transaction
  uint8_t tx[7] = {0x3B | 0x80, 0, 0, 0, 0, 0, 0};
  uint8_t rx[7];
  digitalWrite(PIN_CS, LOW);
  SPI.transferBytes(tx, rx, 7);
  digitalWrite(PIN_CS, HIGH);
  for (int k = 0; k < 6; k++) b[k] = rx[k + 1];
}

float measureRate() {                  // new readings in 0.2 s
  uint8_t prev[6], cur[6];
  int changes = 0;
  SPI.beginTransaction(fastSPI);
  readAccelBytes(prev);
  uint32_t t0 = micros();
  while (micros() - t0 < 200000) {
    readAccelBytes(cur);
    if (memcmp(cur, prev, 6) != 0) { memcpy(prev, cur, 6); changes++; }
  }
  SPI.endTransaction();
  return changes * 5.0f;
}

bool setupSensor() {
  pinMode(PIN_CS, OUTPUT);
  digitalWrite(PIN_CS, HIGH);
  SPI.begin(PIN_SCK, PIN_MISO, PIN_MOSI, -1);
  delay(100);
  writeReg(0x6B, 0x80);                // reset
  delay(100);
  writeReg(0x6A, 0x10);                // I2C off, SPI only
  writeReg(0x6B, 0x01);                // wake up, best clock
  delay(100);
  uint8_t id = readReg(0x75);
  bool ok = (id == 0x71 || id == 0x73 || id == 0x70);
  Serial.printf("MPU chip ID 0x%02X: %s\n", id, ok ? "OK" : "not answering (check the 6 wires)");
  if (!ok) return false;
  writeReg(0x19, 0x00);
  writeReg(0x1C, 0x10);                // +-8 g
  rangeG = 8;
  delay(20);
  writeReg(0x1D, 0x08);                // accelerometer: 4,000 mode, filter at about 1,100 Hz
  const uint8_t cfg1A[3] = {0x00, 0x07, 0x00};
  const uint8_t cfg1B[3] = {0x00, 0x00, 0x01};
  for (int i = 0; i < 3; i++) {
    writeReg(0x1A, cfg1A[i]);
    writeReg(0x1B, cfg1B[i]);
    delay(50);
    float r = measureRate();
    Serial.printf("  speed setting %d: %.0f new readings per second\n", i + 1, r);
    if (r > 500) fsSensor = r;
    if (r > 3500) break;
  }
  return true;
}

// Keep each NEW reading once. Returns readings per second, 0 if the sensor stopped.
float captureOnce(int& late) {
  uint8_t prev[6], cur[6];
  late = 0;
  uint32_t t0 = 0, t1 = 0, tPrev = 0;
  SPI.beginTransaction(fastSPI);
  readAccelBytes(prev);
  int got = -40;                       // skip the first 40 readings
  uint32_t lastChange = micros();
  const uint32_t lateGap = (uint32_t)(1.5f * 1000000.0f / fsSensor);
  while (got < N) {
    readAccelBytes(cur);
    uint32_t now = micros();
    if (memcmp(cur, prev, 6) != 0) {
      memcpy(prev, cur, 6);
      if (got >= 0) {
        buf[got][0] = (int16_t)((cur[0] << 8) | cur[1]);
        buf[got][1] = (int16_t)((cur[2] << 8) | cur[3]);
        buf[got][2] = (int16_t)((cur[4] << 8) | cur[5]);
        if (got == 0) t0 = now;
        else if (now - tPrev > lateGap) late++;
        tPrev = now;
        t1 = now;
      }
      got++;
      lastChange = now;
    } else if (now - lastChange > 3000) {
      SPI.endTransaction();
      return 0;
    }
  }
  SPI.endTransaction();
  return (N - 1) * 1000000.0f / (float)(t1 - t0);
}

float capture(int& late) {
  UBaseType_t oldPrio = uxTaskPriorityGet(NULL);
  vTaskPrioritySet(NULL, 20);
  float fs = 0;
  for (int attempt = 0; attempt < 3; attempt++) {
    fs = captureOnce(late);
    if (fs <= 0 || late == 0) break;
  }
  vTaskPrioritySet(NULL, oldPrio);
  return fs;
}

// ---------------- ESP-NOW ----------------
void handlePacket(const uint8_t* mac, const uint8_t* data, int len) {
  if (len < 2 || data[0] != MAGIC) return;
  if (data[1] == T_BEACON && len >= (int)sizeof(Beacon)) {
    if (!haveStation || memcmp(stationMac, mac, 6) != 0) {
      memcpy(newMac, mac, 6);
      stationNew = true;
    }
  } else if (data[1] == T_REPORT && len >= (int)sizeof(Report)) {
    memcpy(&lastReport, data, sizeof(Report));
    reportReady = true;
  }
}

#if ESP_IDF_VERSION_MAJOR >= 5
void onRecv(const esp_now_recv_info_t* info, const uint8_t* data, int len) { handlePacket(info->src_addr, data, len); }
#else
void onRecv(const uint8_t* mac, const uint8_t* data, int len) { handlePacket(mac, data, len); }
#endif

bool sendRaw(const void* p, size_t len) {
  for (int tries = 0; tries < 50; tries++) {
    esp_err_t e = esp_now_send(stationMac, (const uint8_t*)p, len);
    if (e == ESP_OK) return true;
    delay(2);                          // the send queue is full: wait a moment
  }
  return false;
}

void sendData(int p) {
  DataPkt d;
  d.magic = MAGIC;
  d.type = T_DATA;
  d.block = blockId;
  d.index = p;
  int first = p * PER_PKT;
  d.count = (first + PER_PKT <= N) ? PER_PKT : (N - first);
  memcpy(d.s, buf[first], d.count * 6);
  sendRaw(&d, 8 + d.count * 6);
  totalSent++;
}

void printMac(const uint8_t* m) {
  Serial.printf("%02X:%02X:%02X:%02X:%02X:%02X", m[0], m[1], m[2], m[3], m[4], m[5]);
}

void setup() {
  Serial.begin(115200);
  delay(300);
  pinMode(PIN_LED, OUTPUT);
  Serial.println("\nVibBox wireless test: PROBE v0.1");
  if (!setupSensor()) Serial.println("Carrying on: the station will still see the link.");

  WiFi.mode(WIFI_STA);
  WiFi.disconnect();
  esp_wifi_set_ps(WIFI_PS_NONE);
  esp_wifi_set_channel(CHANNEL, WIFI_SECOND_CHAN_NONE);
  Serial.print("This probe: ");
  Serial.println(WiFi.macAddress());
  if (esp_now_init() != ESP_OK) { Serial.println("ESP-NOW did not start. Press EN to restart."); return; }
  esp_now_register_recv_cb(onRecv);
  Serial.println("Waiting for the station...");
}

void loop() {
  if (stationNew) {
    stationNew = false;
    if (haveStation) esp_now_del_peer(stationMac);
    memcpy(stationMac, newMac, 6);
    esp_now_peer_info_t peer;
    memset(&peer, 0, sizeof(peer));
    memcpy(peer.peer_addr, stationMac, 6);
    peer.channel = 0;
    peer.encrypt = false;
    haveStation = (esp_now_add_peer(&peer) == ESP_OK);
    Serial.print("Found the station: ");
    printMac(stationMac);
    Serial.println();
  }
  if (!haveStation) {
    static uint32_t t = 0;
    if (millis() - t > 2000) { t = millis(); Serial.println("Waiting for the station (is it on and running the station test?)"); }
    delay(10);
    return;
  }

  // 1. record one block
  int late = 0;
  float fs = capture(late);
  if (fs <= 0) { Serial.println("The sensor stopped answering. Check the 6 wires."); delay(1000); return; }
  blockId++;
  digitalWrite(PIN_LED, HIGH);

  // 2. numbers the station will check against
  Info info;
  memset(&info, 0, sizeof(info));
  info.magic = MAGIC;
  info.type = T_INFO;
  info.block = blockId;
  info.n = N;
  info.packets = NPKT;
  info.perPkt = PER_PKT;
  info.lsbPerG = 32768 / rangeG;
  info.fs = fs;
  for (int a = 0; a < 3; a++) {
    double m = 0, q = 0;
    for (int i = 0; i < N; i++) m += buf[i][a];
    m /= N;
    for (int i = 0; i < N; i++) { double d = buf[i][a] - m; q += d * d; }
    info.rms[a] = (float)(sqrt(q / N) / info.lsbPerG);
  }
  uint32_t sum = 0;
  for (int i = 0; i < N; i++) for (int a = 0; a < 3; a++) sum += (uint16_t)buf[i][a];
  info.sum = sum;

  // 3. send it
  reportReady = false;
  uint32_t tSend = millis();
  sendRaw(&info, sizeof(info));
  for (int p = 0; p < NPKT; p++) sendData(p);

  // 4. the station answers with the packets it missed; send those again (3 tries)
  int lostFirst = -1, resent = 0;
  bool ok = false;
  for (int round = 0; round < 4; round++) {
    uint32_t t0 = millis();
    while (!reportReady && millis() - t0 < 600) delay(1);
    if (!reportReady) break;
    reportReady = false;
    if (lastReport.block != blockId) continue;     // an old answer: wait for the next one
    if (lostFirst < 0) lostFirst = lastReport.missing;
    if (lastReport.missing == 0) { ok = true; break; }
    for (int p = 0; p < NPKT && p < 128; p++)
      if (lastReport.bits[p >> 3] & (1 << (p & 7))) { sendData(p); resent++; }
  }
  uint32_t tDone = millis() - tSend;
  digitalWrite(PIN_LED, LOW);
  totalResent += resent;
  if (ok) blocksOk++; else blocksFailed++;

  Serial.printf("Block %u: %s | %.0f readings/s%s | sent in %lu ms | lost %d of %d, resent %d\n",
                blockId, ok ? "station got it all" : "NOT complete (no answer from station)", fs,
                late ? " (some late)" : "", (unsigned long)tDone, lostFirst < 0 ? 0 : lostFirst, NPKT, resent);
  Serial.printf("   RMS x %.4f  y %.4f  z %.4f g   | so far: %lu ok, %lu failed\n",
                info.rms[0], info.rms[1], info.rms[2], (unsigned long)blocksOk, (unsigned long)blocksFailed);
  delay(200);
}
