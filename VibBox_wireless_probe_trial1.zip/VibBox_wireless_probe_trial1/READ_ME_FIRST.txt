VibBox wireless probe, trial 1  (2026-11-25)
=============================================

1_print_PLA                print these now
   wp_lid_PLA.stl            1 x, turn it upside down (roof on the bed), 4 walls, 25 % infill
   wp_base_PLA_88x68x5.stl   1 x, as it opens, 100 % infill (plastic base for bench tests)
   wp_spacer_PLA_x2.stl      2 x (the file has one spacer), 100 % infill
   .step files of the same parts, for SolidWorks

2_aluminium_base_waterjet  for later: calibration and real measurements
   wp_base_aluminium_88x68x3_waterjet.dxf   mm, 1:1, cut lines only (outline + 7 holes)
   wp_base_aluminium_88x68x3.step
   After the waterjet: tap E (10-32 UNF) and H (M3), countersink T1-T3, P1, P2 underneath.

3_drawings
   aluminium_version_5_sheets.pdf   base, lid, printing, cuts, screws + wiring + build order
   plastic_base_2_sheets.pdf        plastic base, its cut, and its screws

4_assembly_check
   assembly_*.step    every part in place (bought parts are simple blocks) to check the fit
   render_*.png       pictures of the parts

5_wireless_test_code
   two Arduino sketches to test the ESP-NOW link with your 2 ESP32s and the MPU (see README.txt)

The same lid and the same parts inside fit both bases. Only the screws change:
   plastic base:   lid 3 x M3 x 16 countersunk, perfboard 2 x M3 x 16 countersunk + nut
   aluminium base: lid 3 x M3 x 12 countersunk, perfboard 2 x M3 x 14 countersunk + nut
